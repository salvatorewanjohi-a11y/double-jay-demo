( function () {
	const cfg = window.DJ || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text, to = cfg.wa ) => 'https://wa.me/' + ( to || '' ) + '?text=' + encodeURIComponent( text );
	const mins = ( m ) => ( m >= 60 ? Math.floor( m / 60 ) + ' hr' + ( m % 60 ? ' ' + ( m % 60 ) + ' min' : '' ) : m + ' min' );
	const store = {
		get: ( k ) => {
			try {
				return JSON.parse( sessionStorage.getItem( k ) || 'null' );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				sessionStorage.setItem( k, JSON.stringify( v ) );
			} catch ( e ) {}
		},
	};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.dj-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'dj-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'dj-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3400 );
		setTimeout( () => t.remove(), 3900 );
	}
	const addedMsg = () => '✂ Added to your appointment · <a href="' + esc( cfg.checkout || '/checkout/' ) + '">Choose day &amp; time</a>';
	document.body.addEventListener( 'wc-blocks_added_to_cart', ( e ) => {
		if ( ! ( e.detail && e.detail.djQuiet ) ) toast( addedMsg() );
	} );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( addedMsg() ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id, quantity = 1 ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		return cart;
	}
	// ids: services or chosen styles. Opens the appointment drawer once everything is in.
	async function addToCart( ids, btn, quiet ) {
		if ( btn ) btn.disabled = true;
		try {
			let cart;
			for ( const id of [].concat( ids ) ) cart = await addItem( id );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true, detail: { djQuiet: !! quiet } } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			return true;
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your appointment. Please try again.' ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-dj-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.djAdd, b );
	} );

	/* Services, add-ons and labels from the page data --------------------- */
	function bookIndex() {
		const idx = {};
		( ( cfg.book && cfg.book.cats ) || [] ).forEach( ( c ) => c.items.forEach( ( it ) => ( idx[ it.id ] = { ...it, cat: c.name } ) ) );
		// Add-ons are services from the menu too; only one missing from it needs its own entry.
		( ( cfg.book && cfg.book.addons ) || [] ).forEach( ( a ) => {
			if ( ! idx[ a.id ] ) idx[ a.id ] = { name: a.name, opt: '', price: a.price, mins: a.mins, ask: a.ask, cat: 'Add-ons' };
		} );
		return idx;
	}
	const itemName = ( it ) => ( it.opt ? it.name + ': ' + it.opt : it.name );
	const priceText = ( it ) => ( it.ask ? 'price in the shop' : fmt( it.price ) );

	/* WhatsApp summary from the cart -------------------------------------- */
	const idxAll = bookIndex();
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		const known = idxAll[ it.id ];
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + ( known && known.ask ? 'price in the shop' : fmt( money( it.totals.line_total, it.totals ) ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-dj-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your appointment is empty.' );
				return;
			}
			const when = store.get( 'dj-booking' ) || {};
			const lines = [ 'Hi Double Jay, I\'d like to book:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Total: ' + fmt( money( cart.totals.total_price, cart.totals ) ) );
			lines.push( 'Day: ' + ( when.dateLabel || '' ), 'Time: ' + ( when.timeLabel || '' ), 'Barber: ' + ( when.barberLabel || 'First available' ) );
			lines.push( 'Name & phone: ' + ( when.name ? when.name + ', ' + when.phone : '' ) );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your appointment. Please try again.' );
		}
	} );

	/* Service page: style buttons ----------------------------------------- */
	// Turns WooCommerce's option drop-downs into buttons that show each option's price (the drop-downs stay in
	// the form, hidden, so WooCommerce still swaps the price).
	function variationPrices( form ) {
		try {
			return JSON.parse( form.dataset.product_variations || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function initOptions() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.djSw ) return;
			sel.dataset.djSw = '1';
			const form = sel.closest( 'form' );
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			wrap.className = 'dj-sw';
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			const vars = variationPrices( form );
			wrap.innerHTML = opts.map( ( o ) => {
				const v = vars.find( ( x ) => x.attributes && x.attributes[ sel.name ] === o.value );
				return '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span>' + ( v ? '<small>' + esc( fmt( v.display_price ) ) + '</small>' : '' ) + '</button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'dj-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( form );
			} );
			paint();
			updateWaProduct( form );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The service page's WhatsApp button names the style the client picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-dj-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		a.href = waUrl( 'Hi Double Jay, I\'d like to book: ' + a.dataset.djWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.djWaPrice + ')' ) + '. ' + a.dataset.djWaUrl );
	}

	/* Details & video pop-up --------------------------------------------- */
	const choiceNames = ( p ) => ( p.attributes || [] ).filter( ( a ) => a.has_variations ).map( ( a ) => plain( a.name ).toLowerCase() );
	const QV_MAX = 10;
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-dj-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'dj-qv' );
		const body = dlg && dlg.querySelector( '[data-dj-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="dj-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.djQv ) ).json();
			const clip = b.dataset.djClip;
			const video = clip ? '<video src="' + esc( clip ) + '" muted loop playsinline autoplay></video>' : '';
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i || clip ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 || clip ? '<div class="dj-qv__thumbs">' + ( clip ? '<button type="button" class="dj-qv__pov" data-dj-qv-img="v">▶ Video</button>' : '' ) + p.images.map( ( im, i ) => '<button type="button" data-dj-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cats = p.categories && p.categories[ 0 ] ? plain( p.categories[ 0 ].name ) : '';
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View service</a>';
			} else if ( p.variations && p.variations.length && p.variations.length <= QV_MAX ) {
				choose = '<p class="dj-qv__label">' + esc( choiceNames( p ).join( ' & ' ) ) + ': <strong data-dj-qv-picked></strong></p><div class="dj-sw">' + p.variations.map( ( v, i ) => {
					const label = ( v.attributes || [] ).map( ( a ) => plain( a.value ) ).join( ' · ' );
					return '<button type="button" data-dj-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '><span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-dj-add="' + p.variations[ 0 ].id + '" data-dj-qv-buy>Add to my appointment</button>';
			} else if ( p.type === 'variable' ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p )[ 0 ] || 'options' ) + '</a>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-dj-add="' + p.id + '">Add to my appointment</button>';
			}
			body.innerHTML = '<div class="dj-qv__grid"><div class="dj-qv__media"><div class="dj-qv__main">' + video + imgs + '</div>' + thumbs + '</div>' +
				'<div class="dj-qv__info">' + ( cats ? '<p class="dj-eyebrow">' + esc( cats ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="dj-qv__price">' + p.price_html + '</div>' +
				'<div class="dj-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="dj-qv__actions">' + buy + '<a class="dj-link" href="' + esc( p.permalink ) + '">What\'s included →</a></div></div></div>';
			const first = body.querySelector( '[data-dj-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this service. Please try again.</p>';
		}
	} );
	// Option price: the Store API lists variations without it, so fetch the chosen one.
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-dj-qv-body]' );
		$$( '[data-dj-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-dj-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-dj-qv-buy]' );
		if ( buy ) buy.dataset.djAdd = btn.dataset.djQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.djQvVar ) ).json();
			// A slower reply for an earlier pick must not overwrite the current one.
			if ( ! btn.classList.contains( 'is-on' ) ) return;
			const price = box.querySelector( '.dj-qv__price' );
			if ( price && v.price_html ) price.innerHTML = v.price_html;
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-dj-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-dj-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.dj-qv__media' );
		media.querySelectorAll( '.dj-qv__main img' ).forEach( ( im, i ) => ( im.hidden = String( i ) !== t.dataset.djQvImg ) );
		const v = media.querySelector( '.dj-qv__main video' );
		if ( v ) v.hidden = t.dataset.djQvImg !== 'v';
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.dj-dialog' ) ) e.target.close();
		// Close the call / WhatsApp menu when clicking elsewhere.
		$$( 'details.dj-contact[open]' ).forEach( ( d ) => {
			if ( ! d.contains( e.target ) ) d.open = false;
		} );
	} );
	// Stop the pop-up video when it closes.
	document.addEventListener( 'close', ( e ) => {
		if ( e.target.id === 'dj-qv' ) e.target.querySelector( '[data-dj-qv-body]' ).innerHTML = '';
	}, true );

	/* Tabs: price list and booking menus ---------------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const tab = e.target.closest( '[data-dj-tab]' );
		if ( ! tab ) return;
		const key = tab.dataset.djTab;
		const root = tab.closest( '[data-dj-prices]' );
		$$( '[data-dj-tab]', root ).forEach( ( t ) => {
			t.classList.toggle( 'is-on', t === tab );
			t.setAttribute( 'aria-selected', t === tab ? 'true' : 'false' );
		} );
		$$( '[data-dj-pane]', root ).forEach( ( p ) => ( p.hidden = key !== 'all' && p.dataset.djPane !== key ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		const tab = e.target.closest( '[data-dj-cat]' );
		if ( ! tab ) return;
		showCat( tab.closest( 'form' ), tab.dataset.djCat );
	} );
	function showCat( form, key ) {
		$$( '[data-dj-cat]', form ).forEach( ( t ) => {
			t.classList.toggle( 'is-on', t.dataset.djCat === key );
			t.setAttribute( 'aria-selected', t.dataset.djCat === key ? 'true' : 'false' );
		} );
		$$( '[data-dj-cat-pane]', form ).forEach( ( p ) => ( p.hidden = p.dataset.djCatPane !== key ) );
	}

	/* Lookbook: filters, lightbox, "Get this look" ------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const f = e.target.closest( '[data-dj-look-filter]' );
		if ( ! f ) return;
		const root = f.closest( '[data-dj-lookbook]' );
		const key = f.dataset.djLookFilter;
		$$( '[data-dj-look-filter]', root ).forEach( ( t ) => {
			t.classList.toggle( 'is-on', t === f );
			t.setAttribute( 'aria-selected', t === f ? 'true' : 'false' );
		} );
		$$( '[data-dj-look-cat]', root ).forEach( ( l ) => ( l.hidden = key !== 'all' && l.dataset.djLookCat !== key ) );
	} );
	// Lightbox: the photo, its caption, "6 of 20" and arrows through the photos of the same group (visible ones only).
	let lbSet = [];
	let lbAt = 0;
	function lbShow( i ) {
		const dlg = document.getElementById( 'dj-lightbox' );
		if ( ! dlg || ! lbSet.length ) return;
		lbAt = ( i + lbSet.length ) % lbSet.length;
		const b = lbSet[ lbAt ];
		const img = dlg.querySelector( 'img' );
		img.src = b.dataset.djLightbox;
		img.alt = b.dataset.djCaption || '';
		dlg.querySelector( '[data-dj-lb-cap]' ).textContent = b.dataset.djCaption || '';
		dlg.querySelector( '[data-dj-lb-count]' ).textContent = lbSet.length > 1 ? ( lbAt + 1 ) + ' of ' + lbSet.length : '';
		$$( '[data-dj-lb-step]', dlg ).forEach( ( n ) => ( n.hidden = lbSet.length < 2 ) );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-dj-lightbox]' );
		const dlg = document.getElementById( 'dj-lightbox' );
		if ( ! b || ! dlg || ! dlg.showModal ) return;
		const group = b.dataset.djGroup;
		lbSet = group ? $$( '[data-dj-lightbox][data-dj-group="' + group + '"]' ).filter( ( x ) => x.offsetParent !== null ) : [ b ];
		lbShow( Math.max( 0, lbSet.indexOf( b ) ) );
		dlg.showModal();
	} );
	document.addEventListener( 'click', ( e ) => {
		const s = e.target.closest( '[data-dj-lb-step]' );
		if ( s ) lbShow( lbAt + Number( s.dataset.djLbStep ) );
	} );
	document.addEventListener( 'keydown', ( e ) => {
		const dlg = document.getElementById( 'dj-lightbox' );
		if ( ! dlg || ! dlg.open ) return;
		if ( e.key === 'ArrowRight' ) lbShow( lbAt + 1 );
		if ( e.key === 'ArrowLeft' ) lbShow( lbAt - 1 );
	} );

	/* Home page motion ---------------------------------------------------- */
	// The header sits on the hero until the page scrolls, then turns solid white.
	function initHeader() {
		const h = document.querySelector( '.dj-header' );
		if ( ! h || ! document.body.classList.contains( 'home' ) ) return;
		const paint = () => h.classList.toggle( 'is-solid', window.scrollY > 40 || !! document.querySelector( '.is-menu-open' ) );
		window.addEventListener( 'scroll', paint, { passive: true } );
		paint();
	}
	// Step inside: the walk-in video plays while it is on screen; the button pauses it, and a paused video stays paused.
	function initWalkin() {
		$$( '[data-dj-walkin]' ).forEach( ( box ) => {
			const v = box.querySelector( 'video' );
			const btn = box.querySelector( '[data-dj-walkin-toggle]' );
			const reduced = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
			let held = reduced;
			const paint = () => {
				btn.textContent = v.paused ? '▶' : '❚❚';
				btn.setAttribute( 'aria-label', v.paused ? 'Play the video' : 'Pause the video' );
			};
			v.addEventListener( 'play', paint );
			v.addEventListener( 'pause', paint );
			btn.addEventListener( 'click', () => {
				held = ! v.paused;
				if ( v.paused ) v.play().catch( () => {} );
				else v.pause();
			} );
			if ( 'IntersectionObserver' in window ) {
				new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => {
					if ( en.isIntersecting && ! held ) v.play().catch( () => {} );
					else if ( ! en.isIntersecting ) v.pause();
				} ), { threshold: .35 } ).observe( v );
			}
			paint();
		} );
	}
	// The big statement: each word turns black as it scrolls up the screen.
	function initReveal() {
		const blocks = $$( '[data-dj-reveal]' );
		if ( ! blocks.length ) return;
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			blocks.forEach( ( b ) => b.removeAttribute( 'data-dj-reveal' ) );
			return;
		}
		// A word lights up once it rises above two thirds of the screen.
		const paint = () => blocks.forEach( ( b ) => $$( 'span', b ).forEach( ( w ) => w.classList.toggle( 'is-on', w.getBoundingClientRect().top < window.innerHeight * .66 ) ) );
		window.addEventListener( 'scroll', paint, { passive: true } );
		window.addEventListener( 'resize', paint );
		paint();
	}
	// Prices & services: a photo of the service follows the pointer over its row (desktop only).
	function initPreview() {
		const rows = $$( '[data-dj-preview]' );
		if ( ! rows.length || ! window.matchMedia( '(hover: hover)' ).matches ) return;
		const box = document.createElement( 'div' );
		box.className = 'dj-preview';
		box.setAttribute( 'aria-hidden', 'true' );
		document.body.appendChild( box );
		rows.forEach( ( row ) => {
			const sum = row.querySelector( 'summary' );
			sum.addEventListener( 'mouseenter', () => {
				box.style.backgroundImage = 'url("' + row.dataset.djPreview + '")';
				box.classList.add( 'is-on' );
			} );
			sum.addEventListener( 'mouseleave', () => box.classList.remove( 'is-on' ) );
			sum.addEventListener( 'mousemove', ( e ) => {
				box.style.left = e.clientX + 'px';
				box.style.top = e.clientY + 'px';
			} );
		} );
	}
	// Puts a service into the booking engine (on this page, or on the home page's #book).
	function loadLook( id, name ) {
		const form = document.querySelector( '[data-dj-booking]' );
		if ( ! form ) {
			window.location.href = ( cfg.home || '/' ) + '?look=' + encodeURIComponent( id ) + '#book';
			return;
		}
		const input = form.querySelector( 'input[name="item"][value="' + id + '"]' );
		if ( ! input ) return;
		const pane = input.closest( '[data-dj-cat-pane]' );
		if ( pane ) showCat( form, pane.dataset.djCatPane );
		if ( ! input.checked ) {
			input.checked = true;
			input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
		}
		form.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		toast( '✂ ' + esc( name || itemName( idxAll[ id ] || { name: 'Look' } ) ) + ' loaded into your booking · pick a day &amp; time' );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-dj-look]' );
		if ( ! b ) return;
		e.preventDefault();
		loadLook( b.dataset.djLook, b.dataset.djLookName );
	} );

	/* Booking engine ------------------------------------------------------ */
	const pad = ( n ) => String( n ).padStart( 2, '0' );
	function nowNairobi() {
		// The shop's clock (UTC+3, no daylight saving), whatever the visitor's own time zone.
		const d = new Date( Date.now() + 3 * 3600 * 1000 );
		return { date: d.getUTCFullYear() + '-' + pad( d.getUTCMonth() + 1 ) + '-' + pad( d.getUTCDate() ), mins: d.getUTCHours() * 60 + d.getUTCMinutes(), dow: d.getUTCDay() || 7 };
	}
	const dowOf = ( ymd ) => new Date( ymd + 'T12:00:00Z' ).getUTCDay() || 7;
	// Whether a start time can be booked on a day: within the hours (last start 30 min before closing), not past.
	function slotOk( ymd, hhmm ) {
		const h = cfg.open && cfg.open[ dowOf( ymd ) ];
		if ( ! h ) return false;
		const [ hh, mm ] = hhmm.split( ':' ).map( Number );
		const m = hh * 60 + mm;
		const now = nowNairobi();
		return m >= h[ 0 ] * 60 && m <= h[ 1 ] * 60 - 30 && ( ymd !== now.date || m > now.mins + 15 );
	}
	function readBooking( form, idx ) {
		const f = new FormData( form );
		const itemIds = f.getAll( 'item' ).map( Number );
		const addIds = f.getAll( 'addon' ).map( Number ).filter( ( id ) => ! itemIds.includes( id ) );
		const items = [ ...itemIds.map( ( id ) => ( { id, ...idx[ id ] } ) ), ...addIds.map( ( id ) => ( { id, ...idx[ id ], addon: true } ) ) ].filter( ( i ) => i.name );
		const date = f.get( 'date' ) || '';
		const time = f.get( 'time' ) || '';
		const barber = f.get( 'barber' ) || 'any';
		const barberName = String( f.get( 'barber_name' ) || '' ).trim();
		return {
			items, total: items.reduce( ( s, i ) => s + ( i.ask ? 0 : i.price ), 0 ), ask: items.some( ( i ) => i.ask ), mins: items.reduce( ( s, i ) => s + ( i.mins || 0 ), 0 ),
			date, dateLabel: date ? cfg.book.dates[ date ] : '', time, timeLabel: time ? cfg.book.times[ time ] : '',
			barber, barberName, barberLabel: barber === 'regular' ? ( barberName ? barberName + ' (my regular barber)' : 'My regular barber' ) : 'First available barber',
			name: String( f.get( 'name' ) || '' ).trim(), phone: String( f.get( 'phone' ) || '' ).trim(), email: String( f.get( 'email' ) || '' ).trim(), notes: String( f.get( 'notes' ) || '' ).trim(),
		};
	}
	function bookingText( r ) {
		return [
			'Hi Double Jay, I\'d like to book:',
			...r.items.map( ( i ) => '• ' + itemName( i ) + ' – ' + priceText( i ) ),
			'Total: ' + fmt( r.total ) + ( r.ask ? ' + services priced in the shop' : '' ) + ( r.mins ? ' (about ' + mins( r.mins ) + ')' : '' ),
			'Barber: ' + r.barberLabel,
			'Day: ' + ( r.dateLabel || 'flexible' ),
			'Time: ' + ( r.timeLabel || 'flexible' ),
			...( r.notes ? [ 'Notes: ' + r.notes ] : [] ),
			'Name: ' + ( r.name || '' ) + ( r.phone ? ', ' + r.phone : '' ) + ( r.email ? ', ' + r.email : '' ),
		].join( '\n' );
	}
	function initBooking() {
		if ( ! cfg.book ) return;
		const idx = bookIndex();
		$$( '[data-dj-booking]' ).forEach( ( form ) => {
			const lines = form.querySelector( '[data-dj-book-lines]' );
			const total = form.querySelector( '[data-dj-book-total]' );
			const when = form.querySelector( '[data-dj-book-when]' );
			const minsOut = form.querySelector( '[data-dj-book-mins]' );
			const barberOut = form.querySelector( '[data-dj-book-barber]' );
			const note = form.querySelector( '[data-dj-book-note]' );
			const hint = form.querySelector( '[data-dj-day-hint]' );
			const nameBox = form.querySelector( '[data-dj-barber-name]' );
			const wa = form.querySelector( '[data-dj-book-wa]' );
			const reserve = form.querySelector( '[data-dj-book-reserve]' );
			const steps = $$( '.dj-book__steps li', form );
			// Days that are already over (the page may be cached from yesterday) are hidden.
			const today = nowNairobi().date;
			$$( 'input[name="date"]', form ).forEach( ( d ) => ( d.closest( 'label' ).hidden = d.value < today || ! $$( 'input[name="time"]', form ).some( ( t ) => slotOk( d.value, t.value ) ) ) );
			// Remember what was entered on this visit (the details also prefill checkout).
			const saved = store.get( 'dj-booking-form' );
			if ( saved ) {
				Object.entries( saved ).forEach( ( [ k, v ] ) => {
					$$( '[name="' + k + '"]', form ).forEach( ( el ) => {
						if ( el.type === 'checkbox' || el.type === 'radio' ) el.checked = [].concat( v ).map( String ).includes( el.value ) && ! ( el.closest( 'label' ) || {} ).hidden;
						else el.value = v;
					} );
				} );
			}
			// "Get this look" from another page arrives as ?look=<id>.
			const look = new URLSearchParams( window.location.search ).get( 'look' );
			const lookInput = look && form.querySelector( 'input[name="item"][value="' + CSS.escape( look ) + '"]' );
			if ( lookInput ) {
				lookInput.checked = true;
				const pane = lookInput.closest( '[data-dj-cat-pane]' );
				if ( pane ) showCat( form, pane.dataset.djCatPane );
				setTimeout( () => toast( '✂ ' + esc( itemName( idx[ look ] ) ) + ' loaded into your booking · pick a day &amp; time' ), 600 );
			}
			const paintTimes = () => {
				const day = ( form.querySelector( 'input[name="date"]:checked' ) || {} ).value;
				let open = 0;
				$$( 'input[name="time"]', form ).forEach( ( t ) => {
					const ok = !! day && slotOk( day, t.value );
					t.disabled = ! ok;
					t.closest( 'label' ).hidden = ! ok;
					if ( ! ok ) t.checked = false;
					open += ok ? 1 : 0;
				} );
				const h = day && cfg.open[ dowOf( day ) ];
				hint.textContent = day ? cfg.book.dates[ day ] + ': open ' + ( h ? ( h[ 0 ] % 12 || 12 ) + ' am to ' + ( h[ 1 ] % 12 || 12 ) + ' pm' : '' ) + ' · ' + open + ' start times left' : 'Pick a day to see the times.';
			};
			const update = () => {
				paintTimes();
				const r = readBooking( form, idx );
				$$( '.dj-book__items label, .dj-book__addons label, .dj-book__days label, .dj-book__times label, .dj-book__barbers label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				nameBox.hidden = r.barber !== 'regular';
				// How many are picked in each menu, on its tab.
				$$( '[data-dj-cat]', form ).forEach( ( t ) => {
					const n = $$( '[data-dj-cat-pane="' + t.dataset.djCat + '"] input:checked', form ).length;
					t.dataset.count = n || '';
				} );
				lines.innerHTML = r.items.length
					? r.items.map( ( i ) => '<li><span>' + esc( itemName( i ) ) + ( i.addon ? ' <em>add-on</em>' : '' ) + '</span><b>' + esc( i.ask ? 'Ask' : fmt( i.price ) ) + '</b></li>' ).join( '' )
					: '<li class="dj-book__empty">Choose a service to see your total.</li>';
				total.textContent = fmt( r.total ) + ( r.ask ? ' +' : '' );
				minsOut.textContent = r.mins ? '◷ About ' + mins( r.mins ) : '';
				barberOut.textContent = '✂ ' + r.barberLabel;
				when.textContent = [ r.dateLabel, r.timeLabel ].filter( Boolean ).join( ' · ' );
				note.textContent = r.ask ? 'Services marked Ask are priced by your barber in the shop. Nothing is paid online.' : 'Nothing is paid online: pay after your cut, by M-Pesa or cash.';
				wa.href = waUrl( bookingText( r ) );
				store.set( 'dj-booking', { date: r.date, dateLabel: r.dateLabel, time: r.time, timeLabel: r.timeLabel, barber: r.barber, barberLabel: r.barberLabel, notes: [ r.barber === 'regular' && r.barberName ? 'Barber: ' + r.barberName : '', r.notes ].filter( Boolean ).join( '. ' ), name: r.name, phone: r.phone, email: r.email } );
				const keep = {};
				for ( const [ k, v ] of new FormData( form ) ) keep[ k ] = k in keep ? [].concat( keep[ k ], v ) : v;
				store.set( 'dj-booking-form', keep );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			form.addEventListener( 'change', ( e ) => {
				if ( ( e.target.name === 'item' || e.target.name === 'addon' ) && e.target.checked ) {
					const it = idx[ e.target.value ];
					// Styles of one service (skin fade or taper) replace each other; an add-on and the same service are one.
					$$( 'input[name="item"]:checked, input[name="addon"]:checked', form ).forEach( ( other ) => {
						const o = idx[ other.value ];
						if ( other !== e.target && o && ( other.value === e.target.value || ( e.target.name === 'item' && other.name === 'item' && o.name === it.name && o.cat === it.cat ) ) ) other.checked = false;
					} );
					update();
					toast( '✂ ' + esc( itemName( it ) ) + ' added · ' + esc( it.ask ? 'price in the shop' : fmt( it.price ) ) );
				}
				if ( e.target.name === 'time' && e.target.checked ) toast( '◷ ' + esc( cfg.book.dates[ form.querySelector( 'input[name="date"]:checked' ).value ] + ', ' + cfg.book.times[ e.target.value ] ) + ' selected' );
			} );
			wa.addEventListener( 'click', ( e ) => {
				const r = readBooking( form, idx );
				if ( ! r.items.length ) {
					e.preventDefault();
					toast( 'Choose at least one service first.' );
					return;
				}
				toast( '✂ WhatsApp is opening with your booking. Tap send and we confirm your chair.' );
			} );
			reserve.addEventListener( 'click', async () => {
				const r = readBooking( form, idx );
				if ( ! r.items.length ) {
					toast( 'Choose at least one service first.' );
					form.querySelector( '[data-step="1"]' ).scrollIntoView( { behavior: 'smooth', block: 'start' } );
					return;
				}
				if ( ! r.date || ! r.time ) {
					toast( 'Pick a day and a time for your cut.' );
					form.querySelector( '[data-step="4"]' ).scrollIntoView( { behavior: 'smooth', block: 'start' } );
					return;
				}
				const label = reserve.textContent;
				reserve.textContent = 'Reserving…';
				// Reserving twice must not book the same service twice: skip what is already in the appointment.
				let have = [];
				try {
					have = ( ( await getCart() ).items || [] ).map( ( it ) => Number( it.id ) );
				} catch ( err ) {}
				const ids = r.items.map( ( i ) => i.id ).filter( ( id ) => ! have.includes( Number( id ) ) );
				const ok = ids.length ? await addToCart( ids, reserve, true ) : true;
				reserve.textContent = label;
				if ( ok ) {
					toast( '✂ Chair reserved for ' + esc( r.dateLabel + ', ' + r.timeLabel ) + ' · <a href="' + esc( cfg.checkout ) + '">Confirm your details</a>' );
					setTimeout( () => ( window.location.href = cfg.checkout ), 1400 );
				}
			} );
			// Light up the step the client is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	/* Checkout: carry the day, time, barber and notes from the booking engine */
	function prefillCheckout() {
		const b = store.get( 'dj-booking' );
		const data = window.wp && window.wp.data;
		if ( ! b || ! data || ! document.querySelector( '.wp-block-woocommerce-checkout' ) ) return;
		let tries = 0;
		const timer = setInterval( () => {
			const checkout = data.dispatch( 'wc/store/checkout' );
			if ( ( checkout && checkout.setAdditionalFields ) || ++tries > 20 ) {
				clearInterval( timer );
				if ( ! checkout || ! checkout.setAdditionalFields ) return;
				const current = ( data.select( 'wc/store/checkout' ).getAdditionalFields && data.select( 'wc/store/checkout' ).getAdditionalFields() ) || {};
				checkout.setAdditionalFields( {
					...current,
					'dj/date': current[ 'dj/date' ] || b.date || '',
					'dj/time': current[ 'dj/time' ] || b.time || '',
					'dj/barber': current[ 'dj/barber' ] || b.barber || 'any',
					'dj/notes': current[ 'dj/notes' ] || b.notes || '',
				} );
				// Name and phone from step 5, where checkout's own fields are still empty.
				const cart = data.dispatch( 'wc/store/cart' );
				const bill = ( data.select( 'wc/store/cart' ).getCustomerData && data.select( 'wc/store/cart' ).getCustomerData().billingAddress ) || {};
				const [ first, ...rest ] = ( b.name || '' ).split( /\s+/ );
				const next = {};
				if ( first && ! bill.first_name ) next.first_name = first;
				if ( rest.length && ! bill.last_name ) next.last_name = rest.join( ' ' );
				if ( b.phone && ! bill.phone ) next.phone = b.phone;
				if ( b.email && ( ! bill.email || /@localhost/.test( bill.email ) ) ) next.email = b.email;
				if ( Object.keys( next ).length && cart && cart.setBillingAddress ) cart.setBillingAddress( next );
			}
		}, 300 );
	}

	/* Header search -------------------------------------------------------- */
	function initSearch() {
		const dlg = document.getElementById( 'dj-search' );
		if ( ! dlg ) return;
		const input = dlg.querySelector( '[data-dj-search-input]' );
		const out = dlg.querySelector( '[data-dj-search-results]' );
		const all = Object.values( idxAll ).filter( ( i ) => i.url );
		const render = () => {
			const q = input.value.trim().toLowerCase();
			const hits = all.filter( ( i ) => ! q || ( itemName( i ) + ' ' + i.cat ).toLowerCase().includes( q ) ).slice( 0, 12 );
			out.innerHTML = hits.length
				? hits.map( ( i ) => '<li><a href="' + esc( i.url ) + '"><strong>' + esc( itemName( i ) ) + '</strong><em>' + esc( i.cat + ( i.time ? ' · ' + i.time : '' ) ) + '</em></a><b>' + esc( i.ask ? 'Ask' : fmt( i.price ) ) + '</b><button type="button" data-dj-look="' + i.id + '">Book</button></li>' ).join( '' )
				: '<li class="dj-search__none">No service matches "' + esc( q ) + '". Ask us on <a href="' + esc( waUrl( 'Hi Double Jay, do you do: ' + q + '?' ) ) + '" target="_blank" rel="noopener">WhatsApp</a>.</li>';
		};
		document.addEventListener( 'click', ( e ) => {
			if ( ! e.target.closest( '[data-dj-search-open]' ) ) return;
			e.preventDefault();
			render();
			dlg.showModal();
			input.focus();
		} );
		input.addEventListener( 'input', render );
		// Book from the results: into the booking engine, so close the search first.
		out.addEventListener( 'click', ( e ) => {
			if ( e.target.closest( '[data-dj-look]' ) ) dlg.close();
		} );
	}

	/* Location: copy the address, send it to WhatsApp, today's hours ------ */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-dj-copy]' );
		if ( ! b ) return;
		e.preventDefault();
		const text = cfg.address + ' · ' + cfg.maps;
		try {
			await navigator.clipboard.writeText( text );
			toast( '⌖ Address copied · paste it into Maps or a chat' );
		} catch ( err ) {
			window.prompt( 'Copy the address:', text );
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-dj-send-location]' );
		if ( ! b ) return;
		toast( '⌖ Choose your own chat (or "Message yourself") and tap send' );
	} );
	function initHours() {
		const now = nowNairobi();
		$$( '[data-dj-hours]' ).forEach( ( box ) => {
			const row = box.querySelector( '[data-dj-day="' + now.dow + '"]' );
			if ( row ) row.classList.add( 'is-today' );
			const h = cfg.open && cfg.open[ now.dow ];
			const open = h && now.mins >= h[ 0 ] * 60 && now.mins < h[ 1 ] * 60;
			const out = box.querySelector( '[data-dj-hours-now]' );
			if ( out ) {
				out.className = 'dj-hours__now ' + ( open ? 'is-open' : 'is-closed' );
				out.textContent = open ? 'Open now · closes at ' + ( h[ 1 ] % 12 || 12 ) + ' pm' : 'Closed now · we open at 7 am' + ( now.dow === 6 && now.mins >= 19 * 60 ? ' on Monday' : now.dow === 7 ? ' tomorrow' : '' );
			}
		} );
	}

	/* Double Jay Club sign-up: goes to the shop's WhatsApp ------------------ */
	document.addEventListener( 'submit', ( e ) => {
		const form = e.target.closest( '[data-dj-club]' );
		if ( ! form ) return;
		e.preventDefault();
		const f = new FormData( form );
		const name = String( f.get( 'name' ) || '' ).trim();
		const phone = String( f.get( 'phone' ) || '' ).trim();
		if ( ! name || phone.replace( /\D/g, '' ).length < 9 ) {
			toast( 'Add your name and phone number to join.' );
			return;
		}
		window.open( waUrl( 'Hi Double Jay, I\'d like to join the Double Jay Club for grooming offers and priority booking.\nName: ' + name + '\nPhone: ' + phone ), '_blank' );
		toast( '✂ Welcome to the club, ' + esc( name.split( ' ' )[ 0 ] ) + '! Tap send in WhatsApp to confirm.' );
		form.reset();
	} );

	/* Shop clips: play only while on screen ---------------------------- */
	function initClips() {
		const vids = $$( '.dj-clip video, .dj-pdp-clip video, .dj-reel video, .dj-hero2__bg' );
		if ( ! vids.length ) return;
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			vids.forEach( ( v ) => {
				v.removeAttribute( 'autoplay' );
				v.pause();
			} );
			return;
		}
		if ( ! ( 'IntersectionObserver' in window ) ) return;
		const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => {
			if ( en.isIntersecting ) en.target.play().catch( () => {} );
			else en.target.pause();
		} ), { rootMargin: '120px' } );
		vids.forEach( ( v ) => io.observe( v ) );
	}

	function init() {
		initOptions();
		initBooking();
		initSearch();
		initHours();
		initClips();
		initHeader();
		initWalkin();
		initReveal();
		initPreview();
		prefillCheckout();
		// The mini cart and checkout re-render client-side; keep the option buttons in place.
		new MutationObserver( () => initOptions() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
