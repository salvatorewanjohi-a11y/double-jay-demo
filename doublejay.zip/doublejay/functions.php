<?php
/**
 * Double Jay Barbershop child theme: precision cuts, colour and grooming on the 1st floor of the TJ & U Complex,
 * along Rabai Road near Rubis, Buruburu, booked like a shop. Services are products (their styles are variations);
 * the cart is the appointment, and checkout asks for the day, the time and the barber.
 */

const DJ_WHATSAPP = '254752392615'; // "Book your appointment now" number on their Bookings Open post.
const DJ_PHONE    = '0752 392 615';
const DJ_TEL      = '+254752392615';
const DJ_IG       = 'https://www.instagram.com/doublejaybarbershop/';
// The building's pin on Google Maps (TJ & U Auto Garage's listing, same complex).
const DJ_LAT      = '-1.2790638';
const DJ_LNG      = '36.8725757';
const DJ_MAPS     = 'https://www.google.com/maps/search/?api=1&query=-1.2790638,36.8725757';
const DJ_WAZE     = 'https://waze.com/ul?ll=-1.2790638,36.8725757&navigate=yes';
const DJ_ADDRESS  = 'Double Jay Barbershop, TJ & U Complex, 1st floor, along Rabai Road near Rubis petrol station, Buruburu, Nairobi';
const DJ_HOURS    = 'Mon–Fri 7 am–9 pm · Sat 7 am–7 pm · Sun closed';
const DJ_FONTS    = 'https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..900&family=Manrope:wght@400;500;600;700&display=swap';

// Opening hours from their Bookings Open post: weekdays 7 am–9 pm, Saturdays and holidays 7 am–7 pm, Sundays closed.
// ISO day (1 = Monday) => [ open, close ] in 24 h, or null when closed.
const DJ_OPEN = [ 1 => [ 7, 21 ], 2 => [ 7, 21 ], 3 => [ 7, 21 ], 4 => [ 7, 21 ], 5 => [ 7, 21 ], 6 => [ 7, 19 ], 7 => null ];
// The barber step. Named barbers can be added here once the shop confirms who takes bookings.
const DJ_BARBERS = [ 'any' => 'First available barber', 'regular' => 'My regular barber (name in the notes)' ];
// Add-ons in the booking engine: [ service, option, label ]. All are services on their own menu.
const DJ_ADDONS = [
	[ 'beard-grooming', null, 'Beard grooming & razor line-up' ],
	[ 'face-scrub', null, 'Face scrub with hot towel' ],
	[ 'hot-towel-shave', null, 'Hot towel shave' ],
	[ 'hair-wash', null, 'Hair wash' ],
	[ 'texturizer', null, 'Texturizer for waves & curl' ],
	[ 'back-massage', null, 'Back massage' ],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'dj-fonts', DJ_FONTS, [], null );
	wp_enqueue_style( 'dj', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'dj', $uri . '/assets/dj.js', [], filemtime( $dir . '/assets/dj.js' ), true );
	wp_localize_script( 'dj', 'DJ', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => DJ_WHATSAPP,
		'address'  => DJ_ADDRESS,
		'maps'     => DJ_MAPS,
		'open'     => DJ_OPEN,
		// Services for the booking engine and the header search (small, so every page has it).
		'book'     => dj_booking_data(),
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'dj-fonts', DJ_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// New WooCommerce installs switch to "Coming soon" after setup.php runs, which hides the shop, cart and service
// pages from logged-out visitors of the demo; keep the store open.
add_filter( 'pre_option_woocommerce_coming_soon', fn() => 'no' );
add_filter( 'woocommerce_coming_soon_exclude', '__return_true' );
// WooCommerce hooks an account icon into the header next to the cart; clients book without accounts.
add_filter( 'hooked_block_woocommerce/customer-account', '__return_null' );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function dj_wa_link( $text = '', $to = DJ_WHATSAPP ) {
	return 'https://wa.me/' . $to . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function dj_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

function dj_product( $slug ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	return $post ? wc_get_product( $post->ID ) : null;
}

/** Services from their reels that are not on their price list yet: the price is confirmed in the shop. */
function dj_is_ask( $product_id ) {
	$parent = wp_get_post_parent_id( $product_id );
	return get_post_meta( $parent ?: $product_id, '_dj_ask', true ) === 'yes';
}

function dj_clip_url( $name ) {
	return $name ? get_stylesheet_directory_uri() . '/assets/clips/' . $name . '.mp4' : '';
}

function dj_photo( $name ) {
	return get_stylesheet_directory_uri() . '/assets/photos/' . $name . '.webp';
}

const DJ_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';
const DJ_CAL_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M7 2h2v2h6V2h2v2h3a1 1 0 0 1 1 1v15a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h3V2Zm12 8H5v9h14v-9ZM5 8h14V6H5v2Zm2 4h4v4H7v-4Z"/></svg>';

/** "Label: value" lines staff type on the product screen, as label => value pairs. */
function dj_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_dj_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function dj_included( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_dj_included', true ) ) ) ) );
}

/** Names of the attributes a client chooses on a variable product, e.g. [ 'Style' ]. */
function dj_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/**
 * Every bookable option of a service, in menu order: [ id, label (the option, or '' for a single price), price ].
 * Read from the products, so price edits in the admin show up in the price list and the booking engine.
 */
function dj_options( WC_Product $p ) {
	if ( ! $p->is_type( 'variable' ) ) {
		return $p->is_purchasable() ? [ [ 'id' => $p->get_id(), 'label' => '', 'price' => (float) $p->get_price() ] ] : [];
	}
	$out = [];
	foreach ( $p->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$out[] = [ 'id' => $vid, 'label' => implode( ', ', array_values( $v->get_attributes() ) ), 'price' => (float) $v->get_price() ];
	}
	return $out;
}

function dj_option_for( WC_Product $p, $label ) {
	foreach ( dj_options( $p ) as $o ) {
		if ( $label === null || $o['label'] === $label ) {
			return $o;
		}
	}
	return null;
}

function dj_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : array_values( $terms );
}

function dj_products_in( $cat ) {
	return wc_get_products( [ 'category' => [ $cat ], 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
}

function dj_price_label( $price, $ask ) {
	return $ask ? 'Price in the shop' : dj_money( $price );
}

/** Opening hours of an ISO weekday as text, e.g. "7 am – 9 pm" or "Closed". */
function dj_hours_text( $dow ) {
	$h = DJ_OPEN[ $dow ] ?? null;
	$f = fn( $x ) => ( $x % 12 ?: 12 ) . ( $x < 12 ? ' am' : ' pm' );
	return $h ? $f( $h[0] ) . ' – ' . $f( $h[1] ) : 'Closed';
}

/** Half-hour start times across the longest day: "07:00" => "7:00 am". The last start is 30 minutes before closing. */
function dj_times() {
	$out = [];
	for ( $m = 7 * 60; $m <= 20 * 60 + 30; $m += 30 ) {
		$h = intdiv( $m, 60 );
		$out[ sprintf( '%02d:%02d', $h, $m % 60 ) ] = ( $h % 12 ?: 12 ) . ':' . sprintf( '%02d', $m % 60 ) . ( $h < 12 ? ' am' : ' pm' );
	}
	return $out;
}

/** The next three weeks as booking days, Sundays left out (closed): Y-m-d => "Wed 21 Oct". */
function dj_booking_dates() {
	$out = [];
	$day = new DateTime( 'today', wp_timezone() );
	for ( $i = 0; $i < 22; $i++ ) {
		if ( DJ_OPEN[ (int) $day->format( 'N' ) ] ) {
			$out[ $day->format( 'Y-m-d' ) ] = ( $i === 0 ? 'Today, ' : ( $i === 1 ? 'Tomorrow, ' : '' ) ) . $day->format( 'D j M' );
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

/** Services by menu, add-ons, days, times and barbers for the booking engine (dj.js does the maths). */
function dj_booking_data() {
	$cats = [];
	foreach ( dj_categories() as $t ) {
		$items = [];
		foreach ( dj_products_in( $t->slug ) as $p ) {
			$name = html_entity_decode( $p->get_name(), ENT_QUOTES );
			$time = (string) get_post_meta( $p->get_id(), '_dj_time', true );
			$mins = (int) get_post_meta( $p->get_id(), '_dj_mins', true );
			$ask  = dj_is_ask( $p->get_id() );
			foreach ( dj_options( $p ) as $o ) {
				$items[] = [ 'id' => $o['id'], 'name' => $name, 'opt' => $o['label'], 'price' => $o['price'], 'time' => $time, 'mins' => $mins, 'ask' => $ask, 'url' => $p->get_permalink(), 'slug' => $p->get_slug() ];
			}
		}
		$cats[] = [ 'slug' => $t->slug, 'name' => html_entity_decode( $t->name, ENT_QUOTES ), 'items' => $items ];
	}
	$addons = [];
	foreach ( DJ_ADDONS as [ $slug, $label, $name ] ) {
		$p = dj_product( $slug );
		$o = $p ? dj_option_for( $p, $label ) : null;
		if ( $o ) {
			$addons[] = [ 'id' => $o['id'], 'name' => $name, 'price' => $o['price'], 'mins' => (int) get_post_meta( $p->get_id(), '_dj_mins', true ), 'ask' => dj_is_ask( $p->get_id() ) ];
		}
	}
	return [ 'cats' => $cats, 'addons' => $addons, 'dates' => dj_booking_dates(), 'times' => dj_times(), 'barbers' => DJ_BARBERS ];
}

function dj_badges_html( WC_Product $product ) {
	$time = get_post_meta( $product->get_id(), '_dj_time', true );
	$perk = get_post_meta( $product->get_id(), '_dj_perk', true );
	$h    = ( $perk ? '<span class="dj-badge dj-badge--perk">' . esc_html( $perk ) . '</span>' : '' ) . ( $time ? '<span class="dj-badge">' . esc_html( $time ) . '</span>' : '' );
	return $h ? '<div class="dj-badges">' . $h . '</div>' : '';
}

// One price for every haircut style shows as that price; different prices show "From".
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? wc_price( $min ) : '<span class="dj-from">From</span> ' . wc_price( $min );
}, 10, 2 );
// Services from their reels that are not on the price list yet.
add_filter( 'woocommerce_get_price_html', fn( $html, $product ) => dj_is_ask( $product->get_id() ) ? '<span class="dj-ask">Price in the shop</span>' : $html, 20, 2 );

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to my appointment' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	$choices = dj_choices( $p );
	return $choices ? 'Choose ' . strtolower( $choices[0] ) : 'Book this';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Taking bookings · ' . DJ_HOURS : 'Fully booked', 10, 2 );

/* -------------------------------------------------------------------------
 * Service page
 * ---------------------------------------------------------------------- */

// Benefit badges, time and key facts above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$perks = array_filter( array_map( 'trim', explode( '|', (string) get_post_meta( $id, '_dj_perks', true ) ) ) );
	$time  = get_post_meta( $id, '_dj_time', true );
	echo '<div class="dj-tags">';
	foreach ( $perks as $perk ) {
		echo '<span class="dj-tag">' . esc_html( $perk ) . '</span>';
	}
	echo ( $time ? '<span class="dj-tag dj-tag--time">' . esc_html( $time ) . '</span>' : '' ) . '</div>';
	if ( dj_is_ask( $id ) ) {
		echo '<p class="dj-note"><strong>Price in the shop.</strong> Book your slot now; your barber confirms the price before starting.</p>';
	}
	$keys = array_slice( dj_specs( $id ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="dj-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Book on WhatsApp, the shop clip, pairings and promises under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$ask   = dj_is_ask( $product->get_id() );
	$price = $ask ? 'price in the shop' : ( $product->is_type( 'variable' ) ? dj_money( $product->get_variation_price( 'min' ) ) : dj_money( $product->get_price() ) );
	$msg   = 'Hi Double Jay, I\'d like to book: ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="dj-wa-order" data-dj-wa-product="' . esc_attr( $product->get_name() ) . '" data-dj-wa-price="' . esc_attr( $price ) . '" data-dj-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( dj_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . DJ_WA_ICON . 'Book on WhatsApp</a>';

	$clip = get_post_meta( $product->get_id(), '_dj_clip', true );
	if ( $clip ) {
		echo '<figure class="dj-pdp-clip"><video src="' . esc_url( dj_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', dj_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>Filmed at Double Jay ·<a href="' . esc_url( DJ_IG ) . '" target="_blank" rel="noopener">more on Instagram</a></figcaption></figure>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="dj-pairs"><p class="dj-pairs__title">Goes well with</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="dj-pairs__add" data-dj-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to your appointment">+ Add</button>'
				: '<a class="dj-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="dj-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="dj-promise"><div><span aria-hidden="true">✂</span><p><strong>Precision cuts, timeless style</strong>Tell your barber the look; we ask before we cut.</p></div><div><span aria-hidden="true">⌖</span><p><strong>TJ &amp; U Complex, 1st floor</strong>Along Rabai Road near Rubis, Buruburu. ' . esc_html( DJ_HOURS ) . '.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay after your cut</strong>Lipa na M-Pesa or cash in the shop. Nothing is paid online.</p></div></div>';
} );

// What's included, and booking & payment tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return $tabs;
	}
	$id       = $product->get_id();
	$specs    = dj_specs( $id );
	$included = dj_included( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'About this service';
	}
	if ( $specs || $included ) {
		$tabs['dj_included'] = [
			'title'    => 'What\'s included',
			'priority' => 5,
			'callback' => function () use ( $specs, $included ) {
				echo '<div class="dj-sheet">';
				if ( $included ) {
					echo '<div><h3>In the chair</h3><ul class="dj-checks">';
					foreach ( $included as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ul></div>';
				}
				echo '<div><h3>Good to know</h3><table class="dj-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div></div>';
			},
		];
	}
	$tabs['dj_booking'] = [
		'title'    => 'Booking & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Book online:</strong> add the service, then choose the day, the time and your barber at checkout, or use our <a href="' . esc_url( home_url( '/#book' ) ) . '">booking engine</a>. We call, SMS or WhatsApp to confirm your chair.</li><li><strong>Walk-ins:</strong> welcome whenever a chair is free; a booking holds yours.</li><li><strong>Where:</strong> TJ &amp; U Complex, 1st floor, along Rabai Road near Rubis petrol station, Buruburu (<a href="' . esc_url( DJ_MAPS ) . '" target="_blank" rel="noopener">map</a>).</li><li><strong>Hours:</strong> ' . esc_html( DJ_HOURS ) . '.</li><li><strong>Pay:</strong> Lipa na M-Pesa or cash after your cut.</li><li><strong>WhatsApp:</strong> prefer to chat? Message ' . esc_html( DJ_PHONE ) . '.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Service cards
 * ---------------------------------------------------------------------- */

function dj_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo), the video badge and the details pop-up on card images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = dj_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'dj-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$clip  = get_post_meta( $product->get_id(), '_dj_clip', true );
	$extra = ( $clip ? '<span class="dj-pov" aria-hidden="true">▶ Watch</span>' : '' )
		. sprintf( '<button type="button" class="dj-qv-btn" data-dj-qv="%1$d" data-dj-clip="%3$s" aria-label="Details of %2$s">%4$s</button>', $product->get_id(), esc_attr( $product->get_name() ), esc_url( dj_clip_url( $clip ) ), $clip ? 'Details &amp; video' : 'Quick view' );
	$pos   = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Label above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = dj_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_dj_badge', true ) : '';
	return ( $badge ? '<p class="dj-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Benefit and time badges on cards.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = dj_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	return dj_badges_html( $product ) . $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page sections
 * ---------------------------------------------------------------------- */

// Service menus: one tile per category, with the photo of its first service.
add_shortcode( 'dj_services', function () {
	$sub = [
		'haircuts'    => 'Skin fade · Taper fade · Executive cut · Buzz cut',
		'beard-shave' => 'Beard grooming · Razor line-up · Hot towel shave',
		'colour'      => 'Black dye · Creme of Nature · Platinum · Texturizer',
		'grooming'    => 'Face scrub · Full facial · Hair wash · Back massage',
		'hands-feet'  => 'Manicure · Pedicure',
		'kids'        => 'Kids haircut · Small designs',
		'packages'    => 'Cut · Beard · Scrub · Massage',
	];
	// Menus whose first service has a brand card show a service with a real photo from the shop instead.
	$cover = [ 'colour' => 'coloured-dye', 'hands-feet' => 'pedicure' ];
	$h     = '<div class="dj-services">';
	foreach ( dj_categories() as $t ) {
		$list = dj_products_in( $t->slug );
		$show = isset( $cover[ $t->slug ] ) ? dj_product( $cover[ $t->slug ] ) : ( $list ? reset( $list ) : null );
		$from = null;
		foreach ( $list as $p ) {
			if ( ! dj_is_ask( $p->get_id() ) ) {
				foreach ( dj_options( $p ) as $o ) {
					$from = $from === null ? $o['price'] : min( $from, $o['price'] );
				}
			}
		}
		$h .= sprintf(
			'<a class="dj-service dj-service--%s" href="%s"><span class="dj-service__img">%s</span><span class="dj-service__txt"><strong>%s</strong><em>%s</em><span>%s · %d %s →</span></span></a>',
			esc_attr( $t->slug ),
			esc_url( get_term_link( $t ) ),
			$show ? $show->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '',
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? '' ),
			$from !== null ? 'From ' . esc_html( dj_money( $from ) ) : 'Ask in the shop',
			count( $list ),
			count( $list ) === 1 ? 'service' : 'services'
		);
	}
	return $h . '</div>';
} );

// Prices & services: one row per service ("From KSh 400 ▾") that opens to its styles, each with a Book button.
// On desktop a photo of the service follows the pointer over the row (dj.js).
add_shortcode( 'dj_price_list', function () {
	$cats = dj_categories();
	if ( ! $cats ) {
		return '';
	}
	$h = '<div class="dj-svcs" data-dj-svcs>';
	foreach ( $cats as $t ) {
		foreach ( dj_products_in( $t->slug ) as $p ) {
			$time  = (string) get_post_meta( $p->get_id(), '_dj_time', true );
			$ask   = dj_is_ask( $p->get_id() );
			$opts  = dj_options( $p );
			$min   = $opts ? min( array_column( $opts, 'price' ) ) : 0;
			$max   = $opts ? max( array_column( $opts, 'price' ) ) : 0;
			$price = $ask ? 'Price in the shop' : ( $min === $max ? dj_money( $min ) : 'From ' . dj_money( $min ) );
			$img   = wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_single' );
			$h    .= '<details class="dj-svc"' . ( $img ? ' data-dj-preview="' . esc_url( $img ) . '"' : '' ) . '><summary><span class="dj-svc__name">' . esc_html( $p->get_name() ) . '<small>' . esc_html( $t->name . ( $time ? ' · ' . $time : '' ) ) . '</small></span><span class="dj-svc__price' . ( $ask ? ' is-ask' : '' ) . '">' . esc_html( $price ) . '</span><span class="dj-svc__chev" aria-hidden="true"></span></summary>'
				. '<div class="dj-svc__body"><a class="dj-svc__img" href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ) . '</a><div><p>' . esc_html( wp_strip_all_tags( $p->get_short_description() ) ) . '</p><ul>';
			foreach ( $opts as $o ) {
				$label = $o['label'] !== '' ? $o['label'] : $p->get_name();
				$h    .= '<li><span>' . esc_html( $label ) . '</span><b' . ( $ask ? ' class="is-ask"' : '' ) . '>' . esc_html( dj_price_label( $o['price'], $ask ) ) . '</b><button type="button" class="dj-svc__book" data-dj-look="' . (int) $o['id'] . '" data-dj-look-name="' . esc_attr( $label ) . '">● Book</button></li>';
			}
			$h .= '</ul><a class="dj-link" href="' . esc_url( $p->get_permalink() ) . '">What\'s included →</a></div></div></details>';
		}
	}
	return $h . '</div><p class="dj-small dj-svcs__foot">Prices in KSh from our own price list. Times are typical. "Price in the shop" services are priced by your barber before starting.</p>';
} );

// Step inside: a big photo of the shop with a strip of thumbnails under it (dj.js swaps them).
add_shortcode( 'dj_tour', function () {
	$shots = [ 'wide-shop' => 'The shop floor', 'wide-stations' => 'Barber stations', 'wide-chair-gold' => 'Gold-trim barber chair', 'wide-wash' => 'Wash basins', 'wide-glass' => 'Our badge on the glass', 'wide-lounge' => 'The waiting lounge', 'wide-ceiling' => 'Lights and mirrors', 'wide-chair' => 'Leather barber chair', 'wide-basins' => 'Lean back at the basin' ];
	$first = array_key_first( $shots );
	$h     = '<div class="dj-tour" data-dj-tour><figure class="dj-tour__main"><img src="' . esc_url( dj_photo( $first ) ) . '" alt="' . esc_attr( $shots[ $first ] ) . '" width="1200" height="675" loading="lazy" data-dj-tour-img><figcaption data-dj-tour-cap>' . esc_html( $shots[ $first ] ) . '</figcaption><button type="button" class="dj-tour__nav is-prev" data-dj-tour-step="-1" aria-label="Previous photo">‹</button><button type="button" class="dj-tour__nav is-next" data-dj-tour-step="1" aria-label="Next photo">›</button></figure><div class="dj-tour__thumbs">';
	foreach ( $shots as $n => $label ) {
		$h .= '<button type="button" data-dj-tour-src="' . esc_url( dj_photo( $n ) ) . '" data-dj-tour-label="' . esc_attr( $label ) . '"' . ( $n === $first ? ' class="is-on"' : '' ) . '><img src="' . esc_url( dj_photo( $n ) ) . '" alt="" width="120" height="68" loading="lazy"></button>';
	}
	return $h . '</div></div>';
} );

// Why people choose us: four numbered cards (a photo shows on hover) beside the badge tile and a quote.
add_shortcode( 'dj_why', function () {
	$cards = [
		[ 'Precision every time', 'Skin fades, tapers and razor-sharp line-ups, blended clean and brushed in by master barbers.', 'look-skin-fade' ],
		[ 'Colour & hair art', 'Blonde to platinum, blond to peach, graffiti-style designs. Why blend in when you can stand out?', 'look-platinum' ],
		[ 'More than a cut', 'Hot towel shaves, face scrubs, facials, a hair wash and back massages. Come for the cut, stay for the soft life.', 'look-facial' ],
		[ 'Young kings welcome', 'Patient, gentle cuts for kids from KSh 200, so parents and sons can sit side by side.', 'look-kid-design' ],
	];
	$h = '<div class="dj-why2"><div class="dj-why2__grid">';
	foreach ( $cards as $i => [ $title, $text, $img ] ) {
		$h .= '<div class="dj-why2__card"><img src="' . esc_url( dj_photo( $img ) ) . '" alt="" loading="lazy" width="720" height="900"><span class="dj-why2__num">0' . ( $i + 1 ) . '</span><div><h3>' . esc_html( $title ) . '</h3><p>' . esc_html( $text ) . '</p></div><span class="dj-why2__arrow" aria-hidden="true">↗</span></div>';
	}
	$h .= '</div><div class="dj-why2__side"><div class="dj-why2__badge"><img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/emblem.png' ) . '" alt="Double Jay Barbershop badge" width="360" height="360" loading="lazy"><span>Rabai Road\'s grooming lounge</span></div><p class="dj-why2__quote">"Your hair is your crown. Wear it sharp."</p><a class="dj-btn dj-btn--dark" href="#book">● Book online</a></div></div>';
	return $h;
} );

// Service reels: tall video cards with a big label, cut from their own reels.
add_shortcode( 'dj_reels', function () {
	$reels = [ [ 'fade', 'Haircuts', 'adult-haircut' ], [ 'shave', 'Shaving', 'beard-grooming' ], [ 'platinum', 'Colour', 'coloured-dye' ], [ 'facial', 'Facials', 'facial' ], [ 'massage', 'Massage', 'back-massage' ] ];
	$h     = '<div class="dj-reels">';
	foreach ( $reels as [ $clip, $label, $slug ] ) {
		$p  = dj_product( $slug );
		$h .= '<a class="dj-reel" href="' . esc_url( $p ? $p->get_permalink() : DJ_IG ) . '"><video src="' . esc_url( dj_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', dj_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="none"></video><span>' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</div>';
} );

// A strip of photos that scrolls on its own (the list twice, for a seamless loop).
add_shortcode( 'dj_strip', function () {
	$imgs = [ 'look-waves', 'wide-glass', 'look-blonde', 'look-retwist', 'look-shave', 'look-graffiti', 'look-locs', 'look-lineup', 'chair' ];
	$row  = '';
	foreach ( $imgs as $n ) {
		$row .= '<img src="' . esc_url( dj_photo( $n ) ) . '" alt="" loading="lazy" width="720" height="900">';
	}
	return '<div class="dj-strip" aria-hidden="true"><div class="dj-strip__track">' . $row . $row . '</div></div>';
} );

// Barbers: portraits from their reels. No names are public, so each card says what they are filmed doing.
add_shortcode( 'dj_barbers', function () {
	$cards = [ [ 'barber-fades', 'Fades & line-ups' ], [ 'barber-colour', 'Colour & platinum' ], [ 'barber-shave', 'Hot towel & beard' ], [ 'barber-grooming', 'Facials & grooming' ] ];
	$h     = '<div class="dj-barbers">';
	foreach ( $cards as [ $img, $label ] ) {
		$h .= '<figure class="dj-barber"><img src="' . esc_url( dj_photo( $img ) ) . '" alt="A Double Jay barber at work: ' . esc_attr( strtolower( $label ) ) . '" loading="lazy" width="720" height="960"><figcaption>' . esc_html( $label ) . '</figcaption></figure>';
	}
	return $h . '</div>';
} );

// Styled right: a wall of their photos, fading out at the edges, each opening in the lightbox.
add_shortcode( 'dj_mosaic', function () {
	$imgs = [ 'look-chair', 'about', 'look-platinum', 'tour-stations', 'look-skin-fade', 'look-wash', 'look-beard', 'wide-glass', 'look-kid-design', 'look-massage', 'look-peach', 'tour-wash', 'look-lineup', 'look-locs', 'look-facial', 'barber-colour', 'look-waves', 'tour-chair' ];
	$h    = '<div class="dj-mosaic">';
	foreach ( $imgs as $n ) {
		$h .= '<button type="button" data-dj-lightbox="' . esc_url( dj_photo( $n ) ) . '" data-dj-caption="Double Jay Barbershop" data-dj-group="mosaic"><img src="' . esc_url( dj_photo( $n ) ) . '" alt="" loading="lazy" width="400" height="400"></button>';
	}
	return $h . '</div>';
} );

// The booking engine: services × add-ons × barber × day & time × your details, with a live total. dj.js does the rest.
add_shortcode( 'dj_booking', function () {
	$b = dj_booking_data();
	if ( ! $b['cats'] ) {
		return '';
	}
	$price = fn( $it ) => $it['ask'] ? 'Ask' : dj_money( $it['price'] );
	ob_start();
	?>
	<form class="dj-book" data-dj-booking novalidate>
		<ol class="dj-book__steps" aria-hidden="true"><li class="is-on">Services</li><li>Add-ons</li><li>Barber</li><li>Day &amp; time</li><li>Your details</li></ol>
		<div class="dj-book__grid">
			<div class="dj-book__main">
				<fieldset class="dj-book__step" data-step="1">
					<legend><span>1</span> Choose your services</legend>
					<div class="dj-book__cats" role="tablist">
						<?php foreach ( $b['cats'] as $i => $c ) : ?>
							<button type="button" role="tab" data-dj-cat="<?php echo esc_attr( $c['slug'] ); ?>"<?php echo $i ? '' : ' class="is-on"'; ?>><?php echo esc_html( $c['name'] ); ?></button>
						<?php endforeach; ?>
					</div>
					<?php foreach ( $b['cats'] as $i => $c ) : ?>
						<div class="dj-book__items" data-dj-cat-pane="<?php echo esc_attr( $c['slug'] ); ?>"<?php echo $i ? ' hidden' : ''; ?>>
							<?php foreach ( $c['items'] as $it ) : ?>
								<label><input type="checkbox" name="item" value="<?php echo (int) $it['id']; ?>"><span><strong><?php echo esc_html( $it['opt'] !== '' ? $it['opt'] : $it['name'] ); ?></strong><?php if ( $it['opt'] !== '' ) : ?><em><?php echo esc_html( $it['name'] ); ?></em><?php endif; ?><small><?php echo esc_html( $it['time'] ); ?></small></span><b<?php echo $it['ask'] ? ' class="is-ask"' : ''; ?>><?php echo esc_html( $price( $it ) ); ?></b></label>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</fieldset>

				<fieldset class="dj-book__step" data-step="2">
					<legend><span>2</span> Add-ons</legend>
					<div class="dj-book__addons">
						<?php foreach ( $b['addons'] as $a ) : ?>
							<label><input type="checkbox" name="addon" value="<?php echo (int) $a['id']; ?>"><span><?php echo esc_html( $a['name'] ); ?></span><b<?php echo $a['ask'] ? ' class="is-ask"' : ''; ?>><?php echo $a['ask'] ? 'Ask' : '+ ' . esc_html( dj_money( $a['price'] ) ); ?></b></label>
						<?php endforeach; ?>
					</div>
				</fieldset>

				<fieldset class="dj-book__step" data-step="3">
					<legend><span>3</span> Your barber</legend>
					<div class="dj-book__barbers" role="radiogroup" aria-label="Barber">
						<?php foreach ( $b['barbers'] as $k => $v ) : ?>
							<label><input type="radio" name="barber" value="<?php echo esc_attr( $k ); ?>"<?php echo $k === 'any' ? ' checked' : ''; ?>><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/emblem.png' ); ?>" alt="" width="44" height="44"><span><strong><?php echo esc_html( $k === 'any' ? 'First available' : 'My regular barber' ); ?></strong><em><?php echo esc_html( $k === 'any' ? 'Any of our master barbers, soonest chair' : 'Tell us who and we hold their chair' ); ?></em></span></label>
						<?php endforeach; ?>
					</div>
					<label class="dj-book__notes" data-dj-barber-name hidden>Barber's name<input type="text" name="barber_name" maxlength="40" placeholder="Who usually cuts your hair?"></label>
				</fieldset>

				<fieldset class="dj-book__step" data-step="4">
					<legend><span>4</span> Day &amp; time</legend>
					<div class="dj-book__days" role="radiogroup" aria-label="Day">
						<?php
						foreach ( $b['dates'] as $k => $v ) :
							$d = new DateTime( $k, wp_timezone() );
							?>
							<label><input type="radio" name="date" value="<?php echo esc_attr( $k ); ?>"><span><small><?php echo esc_html( str_starts_with( $v, 'Today' ) ? 'Today' : ( str_starts_with( $v, 'Tomorrow' ) ? 'Tmrw' : $d->format( 'D' ) ) ); ?></small><strong><?php echo esc_html( $d->format( 'j' ) ); ?></strong><em><?php echo esc_html( $d->format( 'M' ) ); ?></em></span></label>
						<?php endforeach; ?>
					</div>
					<p class="dj-book__hint" data-dj-day-hint>Pick a day to see the times.</p>
					<div class="dj-book__times" role="radiogroup" aria-label="Time" data-dj-times>
						<?php foreach ( $b['times'] as $k => $v ) : ?>
							<label><input type="radio" name="time" value="<?php echo esc_attr( $k ); ?>" disabled><span><?php echo esc_html( $v ); ?></span></label>
						<?php endforeach; ?>
					</div>
				</fieldset>

				<fieldset class="dj-book__step" data-step="5">
					<legend><span>5</span> Your details</legend>
					<div class="dj-book__fields">
						<label>Full name<input type="text" name="name" autocomplete="name" required></label>
						<label>Phone number <em>(for SMS &amp; M-Pesa)</em><input type="tel" name="phone" autocomplete="tel" inputmode="tel" required placeholder="07XX XXX XXX"></label>
						<label>Email <em>(optional)</em><input type="email" name="email" autocomplete="email"></label>
					</div>
					<label class="dj-book__notes">Special notes <em>(optional)</em><textarea name="notes" rows="2" placeholder="e.g. booking for my son too, the fade you want, sensitive scalp"></textarea></label>
				</fieldset>
			</div>

			<aside class="dj-book__summary" aria-live="polite">
				<p class="dj-book__label">Your appointment</p>
				<ul class="dj-book__lines" data-dj-book-lines><li class="dj-book__empty">Choose a service to see your total.</li></ul>
				<div class="dj-book__meta"><span data-dj-book-mins></span><span data-dj-book-barber></span></div>
				<div class="dj-book__total"><span>Total</span><strong data-dj-book-total>KSh 0</strong></div>
				<p class="dj-book__when" data-dj-book-when></p>
				<p class="dj-small" data-dj-book-note>Nothing is paid online: pay after your cut, by M-Pesa or cash.</p>
				<button type="button" class="wp-element-button dj-book__reserve" data-dj-book-reserve>Reserve my chair</button>
				<a class="dj-wa-order dj-book__wa" data-dj-book-wa href="<?php echo esc_url( dj_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo DJ_WA_ICON; ?>Book via WhatsApp</a>
			</aside>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Category chips above shop, category and search pages.
function dj_chip( $label, $url, $on, $count = null ) {
	return sprintf( '<a class="dj-chip%s" href="%s">%s%s</a>', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}
add_shortcode( 'dj_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h       = '<nav class="dj-filters" aria-label="Filter services">' . dj_chip( 'All services', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( dj_categories() as $t ) {
		$h .= dj_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	return $h . '</nav>';
} );

/**
 * Lookbook: [ photo, caption, filter, service slug, option (null = first) ]. Every photo is from their own
 * Instagram. Looks without a service on the price list (locs, retwists) ask on WhatsApp instead.
 */
function dj_looks() {
	return [
		[ 'look-skin-fade', 'Skin fade', 'cuts', 'adult-haircut', 'Skin fade' ],
		[ 'look-platinum', 'Blonde to platinum', 'colour', 'coloured-dye', null ],
		[ 'look-kid-design', 'Clean cut with a small design', 'kids', 'kids-haircut', null ],
		[ 'look-shave', 'Hot towel shave', 'beard', 'hot-towel-shave', null ],
		[ 'look-waves', 'Waves, brushed in', 'cuts', 'texturizer', null ],
		[ 'look-peach', 'Blond to peach', 'colour', 'coloured-dye', null ],
		[ 'look-lineup', 'Clipper line-up', 'cuts', 'adult-haircut', 'Taper fade' ],
		[ 'look-facial', 'Charcoal mask facial', 'grooming', 'facial', null ],
		[ 'look-graffiti', 'Graffiti-style colour', 'colour', 'coloured-dye', null ],
		[ 'look-beard', 'Razor-sharp beard line', 'beard', 'beard-grooming', null ],
		[ 'look-retwist', 'Fresh line-up on a retwist', 'cuts', '', null ],
		[ 'look-massage', 'Back massage', 'grooming', 'back-massage', null ],
		[ 'look-blonde', 'Blonde curls', 'colour', 'coloured-dye', null ],
		[ 'look-wash', 'Hair wash at the basin', 'grooming', 'hair-wash', null ],
		[ 'look-locs', 'Locs by Aura Glow, hairline by Double Jay', 'cuts', '', null ],
		[ 'look-chair', 'The massage chair', 'shop', '', null ],
		[ 'tour-stations', 'Our barber stations', 'shop', '', null ],
		[ 'tour-lounge', 'The waiting lounge', 'shop', '', null ],
		[ 'tour-wash', 'Wash basins', 'shop', '', null ],
		[ 'tour-entrance', 'The entrance, 1st floor', 'shop', '', null ],
	];
}
add_shortcode( 'dj_lookbook', function ( $atts ) {
	$atts    = shortcode_atts( [ 'limit' => 0 ], $atts );
	$filters = [ 'all' => 'All looks', 'cuts' => 'Fades & cuts', 'colour' => 'Colour', 'beard' => 'Beard & shave', 'grooming' => 'Grooming', 'kids' => 'Junior kings', 'shop' => 'The shop' ];
	$looks   = dj_looks();
	if ( (int) $atts['limit'] ) {
		$looks = array_slice( $looks, 0, (int) $atts['limit'] );
	}
	$h = '<div class="dj-look-wrap" data-dj-lookbook><div class="dj-look__tabs" role="tablist">';
	foreach ( $filters as $k => $v ) {
		$h .= '<button type="button" role="tab" data-dj-look-filter="' . esc_attr( $k ) . '"' . ( $k === 'all' ? ' class="is-on" aria-selected="true"' : ' aria-selected="false"' ) . '>' . esc_html( $v ) . '</button>';
	}
	$h .= '</div><div class="dj-looks">';
	foreach ( $looks as [ $img, $label, $filter, $slug, $opt ] ) {
		$p   = $slug ? dj_product( $slug ) : null;
		$o   = $p ? dj_option_for( $p, $opt ) : null;
		$btn = $o
			? '<button type="button" class="dj-look__get" data-dj-look="' . (int) $o['id'] . '" data-dj-look-name="' . esc_attr( $label ) . '">Get this look</button>'
			: ( $filter === 'shop' ? '' : '<a class="dj-look__get dj-look__get--wa" href="' . esc_url( dj_wa_link( 'Hi Double Jay, I\'d like this look: ' . $label . '. When can I come in?' ) ) . '" target="_blank" rel="noopener">Ask on WhatsApp</a>' );
		$h  .= '<figure class="dj-look" data-dj-look-cat="' . esc_attr( $filter ) . '"><button type="button" class="dj-look__zoom" data-dj-lightbox="' . esc_url( dj_photo( $img ) ) . '" data-dj-caption="' . esc_attr( $label ) . '" data-dj-group="looks"><img src="' . esc_url( dj_photo( $img ) ) . '" alt="' . esc_attr( $label . ' at Double Jay Barbershop' ) . '" loading="lazy" width="720" height="' . ( str_starts_with( $img, 'tour-' ) ? 720 : 900 ) . '"></button><figcaption><span>' . esc_html( $label ) . ( $o ? '<small>' . esc_html( dj_price_label( $o['price'], dj_is_ask( $p->get_id() ) ) ) . '</small>' : '' ) . '</span>' . $btn . '</figcaption></figure>';
	}
	return $h . '</div></div>';
} );

// Shop clips: muted loops from their own reels, each linking to its service.
add_shortcode( 'dj_clips', function () {
	$clips = [
		[ 'fade', 'Clipper line-up', 'adult-haircut' ],
		[ 'shave', 'Razor beard line', 'beard-grooming' ],
		[ 'platinum', 'Platinum finish', 'coloured-dye' ],
		[ 'facial', 'Charcoal mask facial', 'facial' ],
		[ 'massage', 'Back massage', 'back-massage' ],
		[ 'chair', 'The massage chair', '' ],
	];
	$h = '<div class="dj-clips">';
	foreach ( $clips as [ $clip, $label, $slug ] ) {
		if ( ! file_exists( get_stylesheet_directory() . '/assets/clips/' . $clip . '.mp4' ) ) {
			continue;
		}
		$p  = $slug ? dj_product( $slug ) : null;
		$h .= '<a class="dj-clip" href="' . esc_url( $p ? $p->get_permalink() : DJ_IG ) . '"' . ( $p ? '' : ' target="_blank" rel="noopener"' ) . '><video src="' . esc_url( dj_clip_url( $clip ) ) . '" poster="' . esc_url( str_replace( '.mp4', '.webp', dj_clip_url( $clip ) ) ) . '" muted loop playsinline autoplay preload="none"></video><span>' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</div>';
} );

// Seen on Instagram: their own posts (they have no Google listing or reviews online yet).
add_shortcode( 'dj_seen', function () {
	$cards = [
		[ 'seen-viral', '56 million views', '"When we don\'t know why we are laughing": our collab reel with @padiwubonn, filmed in the shop, passed 56 million views and 1.8 million likes.', 'DbWaEGMtmR2' ],
		[ 'look-platinum', 'From blonde to platinum', 'A full colour transformation in the chair. Why blend in when you can stand out?', 'DOGlDEfDUnF' ],
		[ 'look-facial', 'More than a cut', 'Skincare isn\'t just a luxury, it\'s self-care: a full facial session, from cleanse to glow.', 'DKOu1yytf5-' ],
		[ 'look-chair', 'The ultimate chill spot', 'Not just fresh fades: our massage chair works overtime to melt your stress while you wait.', 'DLZMOX0tpB3' ],
	];
	$h = '<div class="dj-seen">';
	foreach ( $cards as [ $img, $title, $text, $code ] ) {
		$h .= '<a class="dj-seen__card" href="' . esc_url( 'https://www.instagram.com/p/' . $code . '/' ) . '" target="_blank" rel="noopener"><img src="' . esc_url( dj_photo( $img ) ) . '" alt="" loading="lazy" width="720" height="900"><span class="dj-seen__txt"><strong>' . esc_html( $title ) . '</strong><span>' . esc_html( $text ) . '</span><em>View on Instagram →</em></span></a>';
	}
	return $h . '</div>';
} );

// Instagram strip in the footer: their latest looks, each linking to the profile.
add_shortcode( 'dj_insta', function () {
	$h = '<div class="dj-insta">';
	foreach ( [ 'look-skin-fade', 'look-platinum', 'look-kid-design', 'look-shave', 'look-peach', 'look-waves' ] as $n ) {
		$h .= '<a href="' . esc_url( DJ_IG ) . '" target="_blank" rel="noopener" aria-label="Double Jay Barbershop on Instagram"><img src="' . esc_url( dj_photo( $n ) ) . '" alt="" loading="lazy" width="720" height="900"></a>';
	}
	return $h . '</div>';
} );

// Opening hours table; dj.js marks today and whether the shop is open now.
add_shortcode( 'dj_hours', function () {
	$days = [ 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday & holidays', 7 => 'Sunday' ];
	$h    = '<div class="dj-hours" data-dj-hours><p class="dj-hours__now" data-dj-hours-now></p><table><tbody>';
	foreach ( $days as $n => $label ) {
		$h .= '<tr data-dj-day="' . $n . '"><th>' . esc_html( $label ) . '</th><td>' . esc_html( dj_hours_text( $n ) ) . '</td></tr>';
	}
	return $h . '</tbody></table></div>';
} );

// Details pop-up, lightbox and search (filled in by dj.js), and the floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<dialog id="dj-qv" class="dj-dialog dj-qv" aria-label="Service details"><form method="dialog"><button class="dj-dialog__close" aria-label="Close">×</button></form><div data-dj-qv-body></div></dialog>';
	echo '<dialog id="dj-lightbox" class="dj-dialog dj-lightbox" aria-label="Photo"><form method="dialog"><button class="dj-dialog__close" aria-label="Close">×</button></form><img alt=""><button type="button" class="dj-lightbox__nav is-prev" data-dj-lb-step="-1" aria-label="Previous photo">‹</button><button type="button" class="dj-lightbox__nav is-next" data-dj-lb-step="1" aria-label="Next photo">›</button><p><span data-dj-lb-cap></span><small data-dj-lb-count></small></p></dialog>';
	echo '<dialog id="dj-search" class="dj-dialog dj-search" aria-label="Search services"><form method="dialog"><button class="dj-dialog__close" aria-label="Close">×</button></form><label class="dj-search__field"><span class="screen-reader-text">Search services</span><input type="search" placeholder="Search: fade, beard, platinum, kids…" autocomplete="off" data-dj-search-input></label><ul class="dj-search__results" data-dj-search-results></ul></dialog>';
	echo '<a class="dj-wa-float" href="' . esc_url( dj_wa_link( 'Hi Double Jay, I\'d like to book a cut:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with Double Jay Barbershop on WhatsApp">' . DJ_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart (the appointment), checkout, confirmation
 * ---------------------------------------------------------------------- */

function dj_cart_note_html() {
	return '<div class="dj-cart-note"><strong>Next:</strong> choose the day, the time and your barber. Nothing is paid online: you pay after your cut.</div>';
}
function dj_wa_cart_html() {
	return '<button type="button" class="dj-wa-cart" data-dj-wa-cart>' . DJ_WA_ICON . 'Send booking to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => dj_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . dj_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', dj_cart_note_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="dj-wa-cart-wrap">' . dj_wa_cart_html() . '</div>' );

// Appointment words on the cart and checkout buttons.
add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Confirm my appointment' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Choose day, time & barber' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your appointment' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Book now' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View appointment' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact details', 'We send your appointment confirmation here.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Your name & phone', 'For the SMS or WhatsApp confirmation, and M-Pesa.' ],
		'woocommerce/checkout-additional-information-block' => [ 'Your appointment', 'The day, the time, your barber and any notes.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is paid online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// The appointment comes before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

// "Goes well with" is shown next to the button, so skip WooCommerce's own upsell row.
add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

// What the shop needs to know: field => [ label, short label, options (null = text), required ].
function dj_checkout_fields() {
	return [
		'dj/date'   => [ 'Day', 'Day', dj_booking_dates(), true ],
		'dj/time'   => [ 'Time', 'Time', dj_times(), true ],
		'dj/barber' => [ 'Barber', 'Barber', DJ_BARBERS, true ],
		'dj/notes'  => [ 'Notes (your barber\'s name, the look you want, booking for a child too…)', 'Notes', null, false ],
	];
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( dj_checkout_fields() as $id => [ $label, , $options, $required ] ) {
		$field = [ 'id' => $id, 'label' => $label, 'location' => 'order', 'type' => $options ? 'select' : 'text', 'required' => $required ];
		if ( $options ) {
			$field['options'] = array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $options ), $options );
		}
		woocommerce_register_additional_checkout_field( $field );
	}
} );

/** Why a day and time can't be booked ('' when it can): Saturdays close at 7 pm, and today's past times are gone. */
function dj_slot_problem( $date, $time ) {
	if ( ! $date || ! $time ) {
		return '';
	}
	$tz    = wp_timezone();
	$start = DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $time, $tz );
	if ( ! $start ) {
		return 'Please choose a day and a time.';
	}
	$hours = DJ_OPEN[ (int) $start->format( 'N' ) ] ?? null;
	$mins  = (int) $start->format( 'G' ) * 60 + (int) $start->format( 'i' );
	if ( ! $hours ) {
		return 'We are closed on Sundays. Please choose another day.';
	}
	if ( $mins < $hours[0] * 60 || $mins > $hours[1] * 60 - 30 ) {
		return 'That time is outside our hours on ' . $start->format( 'l' ) . ' (' . dj_hours_text( (int) $start->format( 'N' ) ) . '). Please choose another time.';
	}
	if ( $start < new DateTime( 'now', $tz ) ) {
		return 'That time has already passed today. Please choose a later time.';
	}
	return '';
}
add_action( 'woocommerce_blocks_validate_location_order_fields', function ( WP_Error $errors, $fields ) {
	$problem = dj_slot_problem( (string) ( $fields['dj/date'] ?? '' ), (string) ( $fields['dj/time'] ?? '' ) );
	if ( $problem ) {
		$errors->add( 'dj_slot', $problem );
	}
}, 10, 2 );

function dj_booking_code( WC_Order $order ) {
	return 'DJ-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
/** Appointment details from the checkout fields, as short label => readable value. */
function dj_booking_details( WC_Order $order ) {
	$out = [];
	foreach ( dj_checkout_fields() as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' ) {
			$out[ $label ] = $key === 'dj/date' ? wp_date( 'l j F Y', strtotime( $value . ' 12:00' ) ) : ( $options[ $value ] ?? $value );
		}
	}
	return $out;
}
/** Minutes the appointment takes: the typical time of every service booked. */
function dj_order_minutes( WC_Order $order ) {
	$mins = 0;
	foreach ( $order->get_items() as $item ) {
		$mins += (int) get_post_meta( $item->get_product_id(), '_dj_mins', true ) * max( 1, $item->get_quantity() );
	}
	return $mins ?: 40;
}
function dj_order_lines( WC_Order $order ) {
	$lines = [];
	foreach ( $order->get_items() as $item ) {
		$ask     = dj_is_ask( $item->get_product_id() );
		$lines[] = '• ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . ( $ask ? 'price in the shop' : dj_money( $item->get_total() ) );
	}
	return $lines;
}
function dj_whatsapp_order_text( WC_Order $order, $for_me = false ) {
	$d     = dj_booking_details( $order );
	$lines = [ $for_me ? 'My Double Jay Barbershop appointment (' . dj_booking_code( $order ) . '):' : 'Hi Double Jay, I just booked online (' . dj_booking_code( $order ) . '):' ];
	$lines = array_merge( $lines, dj_order_lines( $order ) );
	$lines[] = 'Total: ' . dj_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	foreach ( $d as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	if ( $for_me ) {
		$lines[] = 'Where: ' . DJ_ADDRESS . ' ' . DJ_MAPS;
	} else {
		$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	}
	return implode( "\n", $lines );
}
/** "Add to Google Calendar" link for the appointment. */
function dj_calendar_link( WC_Order $order ) {
	$date = (string) $order->get_meta( '_wc_other/dj/date' );
	$time = (string) $order->get_meta( '_wc_other/dj/time' );
	$start = $date && $time ? DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $time, wp_timezone() ) : null;
	if ( ! $start ) {
		return '';
	}
	$end = ( clone $start )->modify( '+' . dj_order_minutes( $order ) . ' minutes' );
	$utc = new DateTimeZone( 'UTC' );
	$fmt = fn( DateTime $d ) => ( clone $d )->setTimezone( $utc )->format( 'Ymd\THis\Z' );
	return 'https://calendar.google.com/calendar/render?' . http_build_query( [
		'action'   => 'TEMPLATE',
		'text'     => 'Double Jay Barbershop appointment',
		'dates'    => $fmt( $start ) . '/' . $fmt( $end ),
		'details'  => implode( "\n", array_merge( [ 'Booking ' . dj_booking_code( $order ) ], dj_order_lines( $order ), [ 'Call or WhatsApp ' . DJ_PHONE ] ) ),
		'location' => DJ_ADDRESS,
		'ctz'      => 'Africa/Nairobi',
	], '', '&', PHP_QUERY_RFC3986 );
}
// The digital appointment card on the confirmation page.
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$d    = dj_booking_details( $order );
	$cal  = dj_calendar_link( $order );
	$card = '<div class="dj-card-appt"><img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/emblem.png' ) . '" alt="" width="72" height="72"><div><p class="dj-card-appt__brand">Double Jay Barbershop · Appointment</p><p class="dj-card-appt__code">' . esc_html( dj_booking_code( $order ) ) . '</p></div><dl>'
		. '<div><dt>Day</dt><dd>' . esc_html( $d['Day'] ?? '' ) . '</dd></div><div><dt>Time</dt><dd>' . esc_html( $d['Time'] ?? '' ) . '</dd></div><div><dt>Barber</dt><dd>' . esc_html( $d['Barber'] ?? '' ) . '</dd></div><div><dt>Services</dt><dd>' . esc_html( implode( ', ', array_map( fn( $i ) => html_entity_decode( $i->get_name(), ENT_QUOTES ), $order->get_items() ) ) ) . '</dd></div></dl><p class="dj-card-appt__where">TJ &amp; U Complex, 1st floor · along Rabai Road near Rubis</p></div>';
	return $content . '<div class="dj-thanks">' . $card . '<ol><li>We call, SMS or WhatsApp you shortly to confirm your chair.</li><li>Come up to the 1st floor of the TJ &amp; U Complex on Rabai Road (<a href="' . esc_url( DJ_MAPS ) . '" target="_blank" rel="noopener">map</a>). Arrive 5 minutes early.</li><li>Sit back, get sharp, then pay by M-Pesa or cash.</li></ol><div class="dj-thanks__actions">' . ( $cal ? '<a class="wp-element-button dj-btn-ghost" href="' . esc_attr( $cal ) . '" target="_blank" rel="noopener">' . DJ_CAL_ICON . 'Add to Google Calendar</a>' : '' ) . '<a class="wp-element-button dj-wa-btn" href="' . esc_attr( dj_wa_link( dj_whatsapp_order_text( $order ) ) ) . '" target="_blank" rel="noopener">' . DJ_WA_ICON . 'Send booking to the shop</a><a class="wp-element-button dj-btn-ghost" href="' . esc_attr( 'https://wa.me/?text=' . rawurlencode( dj_whatsapp_order_text( $order, true ) ) ) . '" target="_blank" rel="noopener">' . DJ_WA_ICON . 'Save it in my WhatsApp</a></div></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Appointment number:</strong> ' . esc_html( dj_booking_code( $order ) ) . '</p>';
} );

// Staff edit the card labels, the facts, what's included and the shop clip on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_dj_badge', 'label' => 'Card label', 'description' => 'Small label above the name, e.g. "Most booked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_dj_perk', 'label' => 'Card badge', 'description' => 'One benefit shown on the card, e.g. "Precision every time".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_dj_perks', 'label' => 'Benefit badges', 'description' => 'Shown on the service page, separated by |, e.g. "Skin fade | Crisp line-up".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_dj_time', 'label' => 'Time', 'description' => 'e.g. "About 40 min". Shown in the price list and the booking engine.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_dj_mins', 'label' => 'Minutes', 'type' => 'number', 'description' => 'How long it takes, for the booking total and the calendar entry.', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_dj_clip', 'label' => 'Shop clip', 'options' => [ '' => 'None', 'fade' => 'Clipper line-up', 'shave' => 'Razor beard line', 'platinum' => 'Platinum finish', 'facial' => 'Facial', 'massage' => 'Back massage', 'chair' => 'Massage chair' ] ] );
	woocommerce_wp_checkbox( [ 'id' => '_dj_ask', 'label' => 'Price in the shop', 'description' => 'Shows "Price in the shop" instead of a price. Untick once you set a price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_dj_specs', 'label' => 'Good to know', 'rows' => 5, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_dj_included', 'label' => 'What\'s included', 'rows' => 8, 'description' => 'One item per line.' ] );
	echo '<p class="form-field"><em>Styles (e.g. Skin fade / Taper fade): Attributes → the option list makes the variations; set each price under Variations. "Goes well with" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_dj_badge', '_dj_perk', '_dj_perks', '_dj_time', '_dj_mins', '_dj_clip' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
	$product->update_meta_data( '_dj_ask', isset( $_POST['_dj_ask'] ) ? 'yes' : 'no' ); // phpcs:ignore
	foreach ( [ '_dj_specs', '_dj_included' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan contacts: only the name and phone are needed for an appointment.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	foreach ( [ 'postcode', 'state', 'address_1', 'address_2', 'city' ] as $f ) {
		$locale['KE'][ $f ] = [ 'required' => false, 'hidden' => true ];
	}
	$locale['KE']['phone'] = [ 'required' => true ];
	return $locale;
} );

// Appointment words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'  => 'More from the chair',
		'Continue shopping' => 'Keep browsing services',
		'Order received'    => 'Appointment received',
		'Thank you. Your order has been received.' => 'Thank you. Your appointment request has been received.',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your appointment.' : $text;
}, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0F0F0F\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// booking engine's and price list's grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );
// Our own shortcodes inside HTML blocks (the hours table in the location section).
add_filter( 'render_block_core/html', fn( $c ) => str_contains( $c, '[dj_' ) ? do_shortcode( $c ) : $c );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|poster|data-dj-lightbox)="/(?!/)#', '$1="' . $home, $content );
} );
